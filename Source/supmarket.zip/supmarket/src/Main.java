import GUI.*;
import SQL.*;
public class Main {
    public static void main(String[] args){
        GUI g= new GUI();
        g.mainInterface();
        FinanceManage Fin = new FinanceManage();
        Fin.selesVolumeCollect();
    }
}
