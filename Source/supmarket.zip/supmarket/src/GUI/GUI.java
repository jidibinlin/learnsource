package GUI;

import JDBC.*;
import SQL.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.Statement;
import javax.swing.*;
public class GUI {
    public void mainInterface(){
        JFrame mainframe= new JFrame("mainframe");
        mainframe.setSize(400,300);
        mainframe.setVisible(true);
        mainInterfaceListener ls=new mainInterfaceListener();
    }
}

class mainInterfaceListener extends WindowAdapter {
    public void windowClosing(WindowEvent e){
        Window window=(Window) e.getComponent();
        window.dispose();
    }
}

class Layout{

}