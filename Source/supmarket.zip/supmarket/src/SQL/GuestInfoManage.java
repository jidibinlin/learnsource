package SQL;

import JDBC.connect;
import java.sql.*;

public class GuestInfoManage {
    Statement stmt=null;
    ResultSet rs=null;
}
