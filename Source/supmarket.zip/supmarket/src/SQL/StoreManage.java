package SQL;

import java.sql.*;
import JDBC.connect;

public class StoreManage {
    Statement stmt=null;
    ResultSet rs=null;
}
