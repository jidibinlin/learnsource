package SQL;

import java.sql.*;
import JDBC.connect;

public class ProductManage {
    Statement stmt=null;
    ResultSet rs=null;
}
