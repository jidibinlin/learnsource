package SQL;

import JDBC.connect;
import java.sql.*;

public class EmployeeManage {
    Statement stmt=null;
    ResultSet rs=null;
}
